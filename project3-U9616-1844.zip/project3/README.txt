complie the program by using the make command, one can also clean the directory first by running 'make clean'

run the program with the command ./cube followed by the optional arguements:
			
		-size <integer number> -teamA <integer number> -teamB <integer number> - seed <integer number>

Any of thses can be left blank as there are default values that the variables can be assigned to as well.

After execution the game can be started with the start command, whiuch will initalize the game based on previous user inputs or 
default values. Then the game can begin with user input by using either 's' to single step through the game play by play or 'c'
to let the game auto complete till the end. 'show' command wil show the state of the game board.
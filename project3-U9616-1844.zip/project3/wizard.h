#ifndef _WIZARD_H
#define _WIZARD_H

#include "cube.h"

extern void* wizard_func(void* wizard);

#endif
